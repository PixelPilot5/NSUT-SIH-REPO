from fastapi import FastAPI, Depends, HTTPException
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials # HTTPBearer : Finds/extracts the authentication information from the request, HTTPAuthorizationCredentials : Holds the authentication information that was extracted.
from fastapi.middleware.cors import CORSMiddleware
from models import Simulation, User, UserResponse, Login
from database import session, engine
import database_models
from pwdlib import PasswordHash
from dotenv import load_dotenv
import os
import jwt

# Password hashing
password_hash = PasswordHash.recommended()

# Creating app
app = FastAPI(
    title="FloodSim API",
    description="Backend API for the FloodSim Dam Break Inundation Modelling Platform",
    version="1.0.0"
)

# Adding middleware to properly communicate with frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"]
)

database_models.Base.metadata.create_all(bind=engine)   # Take all the database models registered with my SQLAlchemy Base, look at their metadata, create the corresponding tables if they don't already exist, and use this Engine to communicate with PostgreSQL.

@app.get("/")
def home():
    return {
        "message": "Welcome to FloodSim API!"
    }

#This function's job is:Create a database session and provide it to whoever needs one. So get_db() is a dependency provider.
def get_db():
    db = session()
    try:
        yield db # yield pauses a function and gives a value to the caller, while remembering where it stopped so that it can continue from that point later.
    finally:    # finally executes after the try block, regardless of the outcome of the try block
        db.close()

# JWT SECRET KEY
# JWT : A JWT (JSON Web Token) is a digitally signed piece of information that a server gives to a user after successful login, which the user can then send back with future requests to prove which user they are. It contains the unique id of the user along with a secret server key known only to the backend server. Because only the backend should know this key, it allows the server to trust that a JWT was issued by the backend and has not been modified/tampered with.
load_dotenv()
JWT_SECRET_KEY = os.getenv("JWT_SECRET_KEY")
if not JWT_SECRET_KEY:
    raise ValueError("JWT_SECRET_KEY is not set")
security = HTTPBearer() # We're creating an object called: security that knows how to extract a Bearer token from a request.

# Parts of JWT secret key: 
# JWT
# │
# ├── Header
# │     "How was this ID card signed?"
# │
# ├── Payload
# │     "Who is this ID card for?"
# │
# └── Signature
#       "Can the server trust that this ID card
#        hasn't been tampered with?"

def get_current_user( 
    credentials: HTTPAuthorizationCredentials = Depends(security),  # FastAPI, look at the incoming request, extract the Bearer authentication information, and give it to me as credentials.
    db=Depends(get_db)
):
    token = credentials.credentials

    try:
        payload = jwt.decode(
            token,
            JWT_SECRET_KEY,
            algorithms=["HS256"]
        )

        user_id = int(payload["sub"])

    except (jwt.InvalidTokenError, KeyError, ValueError):
        raise HTTPException(
            status_code=401,
            detail="Invalid or expired token"
        )

    user = db.query(database_models.Users).filter(
        database_models.Users.id == user_id # gives databse user
    ).first()

    if not user:
        raise HTTPException(
            status_code=401,
            detail="User not found"
        )

    return user

# # Function to initialise databse with values
# def init_db():
#     db = session()
#     count = db.query(database_models.Product).count()   # Create a query for the Product table, store the no. of records/rows it has in count variable.
#     if count == 0:  # If databse is empty, then only insert
#         for product in products:
#             #1. product.model_dump(): product is your Pydantic Product object. model_dump() converts it into a normal Python dictionary containing its data.
#             #2. ** : The ** unpacks that dictionary into keyword arguments.
#             #3. database_models.Product(...): This creates a SQLAlchemy Product object, which represents a row that can be stored in your PostgreSQL Product table.
#             db.add(database_models.Product(**product.model_dump()))
#         db.commit()
# init_db()

@app.get("/simulations")
def get_all_simulations(db=Depends(get_db), current_user=Depends(get_current_user)):
    simulations = db.query(database_models.Simulations).filter(
        database_models.Simulations.user_id == current_user.id
    ).all()    
    return simulations

@app.get("/simulations/{id}")
def get_simulation_by_id(id: int, db=Depends(get_db), current_user=Depends(get_current_user)):

    simulation = db.query(database_models.Simulations).filter(
        database_models.Simulations.id == id,
        database_models.Simulations.user_id == current_user.id
    ).first()

    if simulation:
        return simulation

    return "simulation not found"

@app.post("/simulations")
def add_simulation(simulation: Simulation, db=Depends(get_db), current_user=Depends(get_current_user)):

    db_simulation = database_models.Simulations(
        user_id=current_user.id,
        name=simulation.name,
        state=simulation.state,
        district=simulation.district,
        river=simulation.river,
        dam=simulation.dam,
        scenario=simulation.scenario,
        model=simulation.model
    )

    db.add(db_simulation)
    db.commit()
    db.refresh(db_simulation)

    return db_simulation

@app.post("/users", response_model=UserResponse)
def add_user(user: User, db=Depends(get_db)):

    hashed_password = password_hash.hash(user.password)

    db_user = database_models.Users(
        name=user.name,
        email=user.email,
        password=hashed_password
    )

    db.add(db_user)
    db.commit()
    db.refresh(db_user)

    return db_user

@app.post("/login")
def login(user: Login, db=Depends(get_db)):

    db_user = db.query(database_models.Users).filter(
        database_models.Users.email == user.email
    ).first()

    if not db_user:
        return {"message": "User not found"}

    password_correct = password_hash.verify(
        user.password,
        db_user.password
    )

    if not password_correct:
        return {"message": "Incorrect password"}

    token = jwt.encode(
        {"sub": str(db_user.id)},
        JWT_SECRET_KEY,
        algorithm="HS256"
    )

    return {"access_token": token}

@app.delete("/simulations/{id}")
def delete_simulation(
    id: int,
    db=Depends(get_db),
    current_user=Depends(get_current_user)
):
    simulation = db.query(database_models.Simulations).filter(
        database_models.Simulations.id == id,
        database_models.Simulations.user_id == current_user.id
    ).first()

    if not simulation:
        return "simulation not found"

    db.delete(simulation)
    db.commit()

    return {"message": "Simulation deleted successfully"}

@app.get("/users/me", response_model=UserResponse)
def get_current_user_info(
    current_user=Depends(get_current_user)
):
    return current_user