let currentStep = 1;
const totalSteps = 4;

const stepNames = [
    "Study Area",
    "Scenario",
    "Model",
    "Review & Run"
];

function getSelectedScenario() {
    const selected = document.querySelector("[name='scenario']:checked");
    return selected ? selected.value : "Full Dam Break";
}

function getSelectedModel() {
    const selected = document.querySelector("[name='model']:checked");
    return selected ? selected.value : "SPH";
}

function collectSimulationData() {
    return {
        name: `${river.value} ${getSelectedScenario()}`,
        state: state.value,
        district: district.value,
        river: river.value,
        dam: dam.value,
        scenario: getSelectedScenario(),
        model: getSelectedModel()
    };
}

function updateReview() {
    const data = collectSimulationData();

    review.innerHTML = `
        <div class="review-row"><span>Simulation Name</span><b>${data.name}</b></div>
        <div class="review-row"><span>State / Region</span><b>${data.state}</b></div>
        <div class="review-row"><span>District</span><b>${data.district}</b></div>
        <div class="review-row"><span>River</span><b>${data.river}</b></div>
        <div class="review-row"><span>Dam / Lake</span><b>${data.dam}</b></div>
        <div class="review-row"><span>Scenario</span><b>${data.scenario}</b></div>
        <div class="review-row"><span>Model</span><b>${data.model}</b></div>
    `;

    localStorage.setItem("simulationData", JSON.stringify(data));
}

function showStep() {
    document.querySelectorAll(".s").forEach((section) => {
        section.classList.toggle("active", Number(section.dataset.s) === currentStep);
    });

    document.getElementById("step").textContent = `Step ${currentStep} of ${totalSteps}`;
    document.getElementById("back").disabled = currentStep === 1;
    document.getElementById("next").textContent = currentStep === totalSteps
        ? "Run Simulation"
        : "Continue →";

    document.querySelectorAll(".step-item").forEach((item, index) => {
        item.classList.toggle("active", index + 1 === currentStep);
        item.classList.toggle("completed", index + 1 < currentStep);
    });

    if (currentStep === totalSteps) {
        updateReview();
    }
}

document.addEventListener("DOMContentLoaded", () => {
    document.getElementById("next").addEventListener("click", () => {
        if (currentStep < totalSteps) {
            currentStep++;
            showStep();
        } else {
            localStorage.setItem("simulationData", JSON.stringify(collectSimulationData()));
            window.location.href = "simulation-running.html";
        }
    });

    document.getElementById("back").addEventListener("click", () => {
        if (currentStep > 1) {
            currentStep--;
            showStep();
        }
    });


    showStep();
});
