document.addEventListener("DOMContentLoaded",()=>{
  const p=document.querySelector("[data-page]")?.dataset.page;
  document.querySelectorAll("nav a").forEach(a=>{if(a.dataset.p===p)a.classList.add("active")});

  const toggle=()=>{
    document.body.classList.toggle("dark");
    localStorage.setItem("theme",document.body.classList.contains("dark")?"dark":"light");
  };
  if(localStorage.getItem("theme")==="dark")document.body.classList.add("dark");
  document.getElementById("theme")?.addEventListener("click",toggle);
  document.getElementById("themeTop")?.addEventListener("click",toggle);

  const trigger=document.getElementById("profileTrigger");
  const menu=document.getElementById("profileMenu");
  trigger?.addEventListener("click",e=>{
    e.stopPropagation();
    const open=menu?.classList.toggle("show");
    trigger.setAttribute("aria-expanded",open?"true":"false");
  });
  document.addEventListener("click",()=>{
    menu?.classList.remove("show");
    trigger?.setAttribute("aria-expanded","false");
  });
  document.getElementById("logoutBtn")?.addEventListener("click",()=>{
    alert("You have been logged out.");
  });
});
