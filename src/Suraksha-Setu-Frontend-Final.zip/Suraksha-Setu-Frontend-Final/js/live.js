document.addEventListener("DOMContentLoaded", () => {
    const map = L.map("liveMap").setView([22.8, 79.2], 5);

    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution: "© OpenStreetMap"
    }).addTo(map);

    // Station data will be connected here from Priyanshu's dataset.
    // No demo/mock flood stations are shown.
});
