Suraksha-Setu Frontend

Technology: HTML + CSS + Bootstrap + JavaScript + Leaflet.

Run: Extract ZIP -> open folder in VS Code -> install Live Server extension -> right-click index.html -> Open with Live Server.

Current values/maps are demo data. API/GIS/Hydro/GEE integration points are intentionally simple and can be connected later.
